
define(function() {
    return {};
});